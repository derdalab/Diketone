# Author: Jessica CAO
# Date: August 8, 2018
# This script takes a list of DE sets as input
# 1. involk DE analysis from DE.rmd
# 2. involk Clustering from SequenceCluster.r
# 4. internal repopulate un-clustered sequences into clusters
# 3. involk internal repopulation report from report.rmd
remove(list = ls())
library(rmarkdown)
library(openxlsx)
library(reticulate)
scriptDir = getwd()
source_python(paste0(scriptDir,"/auxiliary/Clustering.py"))
source(paste0(scriptDir,"/auxiliary/Sequence_Repopulation.r"))

###############################################################
############# User Interface ##################################
###############################################################
# read the excel file containing all the test and control sets
DEtable = 'example.xlsx'
DataDir = "/media/Data/SequenceSearchingProject/DBData/tableFile/"

###############################################################
singletonRM = 1
clusteringStep = 0.01
mutantRM = 1
hitsNumber = 50
seqHead = ''
## For Tree plot
showLabel = TRUE
UseEdgeLength = TRUE
pThresh = 0.2
###############################################################


# read the excel file
DETbl = read.xlsx(DEtable)
colNames = names(DETbl)
DESets = DETbl[!(is.na(DETbl[,1])), ]
Tags = DETbl[!(is.na(DETbl[,1])), 1]
Labels = DETbl[(is.na(DETbl[,1])),]
Ccols = colNames[regexpr("^control", colNames)!=-1]
DETbl[is.na(DETbl)] = ""
log = ""

eps_clustering = c()
for (tag in Tags){
        print(tag)
        rowIndex = DESets[,1]==tag
        group = DESets[rowIndex,]
        reportGroup = tag
        dataFolder = ''
        
        # DE Analysis
        test =paste0(group[1,'test'],'.txt')
        controls = c()
        fileList = c()
        Groups = c()
        
        filterCounts = group[1,'filterCounts']
        for (ic in 1:length(Ccols)){
                if (! is.na(group[1,Ccols[ic]])){
                        controls = append(controls, paste0(group[1, Ccols[ic]],'.txt'))
                        fileList = append(fileList, group[1, Ccols[ic]])                                    
                        Groups = append(Groups, Labels[rowIndex, Ccols[ic]])
                }
        }
        controls = paste0(controls, collapse = ',')
        fileList = append(fileList, group[1,'test'])
        Groups = append(Groups, Labels[rowIndex,'test'])
        fileList = paste0(fileList, collapse = ',')
        Groups = paste0(Groups, collapse = ',')
        pattern = group[1,'pattern']
        subtitle = group[1,'subtitle']
        library = group[1,'library']
        tarGel = group[1,'tarGel']
        if(is.na(pattern)){
                pattern = ''
        }
        SoftDEControls = group[1,'SoftControls']
        TargetMod = group[1,'ModList']
        if(is.na(TargetMod)){
                TargetMod = ''
        }
        extraComp = group[1,'extraComp'] 
        if(is.na(extraComp)){
                extraComp = ''
        }
        # add the filter of SDB
        nuc_sdb = group[1,'SDB']
        sdb_start = group[1,'SDB_start']
        if(is.na(sdb_start)){
                sdb_start = 0
        }
        if(is.na(group[1,'seqHead'])){
                seqHead = ''
        }else{
                seqHead = group[1,'seqHead']
        }
        if(is.na(group[1,'blackPos'])){
                blackPos = ''
        }else{
                blackPos = group[1,'blackPos']
        }
        
        folderName = tag
        if (!dir.exists(folderName)){
                dir.create(folderName)
        }
        saveName = paste0("DE_",tag,".txt")
        htmlName = paste0("DE_",tag,".html")
        label = Labels[rowIndex,c('test', Ccols)]
        label = label[1, !is.na(label)]
        if(is.na(extraComp)){
                extraComp=''
        }
        
        DEParams = list('singletonRM'=singletonRM, "test" = test, "controls"=controls, "pattern" = pattern, "saveName"=saveName, "filterCounts"=filterCounts,
                        "targetMod"=TargetMod, 'SoftDEControls' = SoftDEControls,'DataDir'=DataDir, 'sdb_start' = sdb_start, 'nuc_sdb' = nuc_sdb, 'mutantRM' = mutantRM, 'extraComp' = extraComp)
        render(paste0(scriptDir,"/auxiliary/DE.rmd"), params = DEParams)
        file.copy(paste0(scriptDir,"/auxiliary/", saveName), scriptDir, overwrite = TRUE)
        file.remove(paste0(scriptDir,"/auxiliary/", saveName))
        file.copy(paste0(scriptDir,"/auxiliary/DE.html"), scriptDir, overwrite = TRUE)
        file.remove(paste0(scriptDir,"/auxiliary/DE.html"))
        tmp = try(file.rename("DE.html", htmlName), TRUE)
        if(inherits(tmp, "try-error")){
                log = paste0(log, "\nWarning: DE in ", folderName, " failed!")
        }

        Results = c(htmlName, saveName)

        # Clustering
        if (!file.exists(saveName)){
                log = paste0(log, "\nWarning: DE in ",folderName, " is not available. No clustering and report will be generated!\n\n")
                file.copy(Results, folderName, overwrite = TRUE)
                file.remove(Results)
                next
        }
        ClusteringRet = -3
        Rlog2 = 0
        Rlog2Step = 0.5
        while(ClusteringRet==-3){
                ClusteringRet = DBSCANClustering(paste0(scriptDir, '/',saveName), step = clusteringStep, retDir = paste0(scriptDir,'/'),pThresh = pThresh, RThresh = 2**Rlog2, RThreshDes =2**(-0.5))
                uMod = ClusteringRet[[2]]
                ClusteringRet = ClusteringRet[[1]]
                Rlog2 = Rlog2+Rlog2Step
                print(paste0("UPDATE R THRESHOLD TO ", Rlog2,"...\n"))
        }
        if(ClusteringRet == -2){
                log = paste0(log, "\nWarning: Clustering in", folderName, " is not available due to p and R values. No clustering and report will be generated!\n\n")
                file.copy(Results, folderName, overwrite = TRUE)
                file.remove(Results)
                next
        }

        clusterName =  paste0("Cluster_",tag,".csv");
        if(ClusteringRet == -1){
                log = paste0(log, "\nWarning: Clustering in", folderName, " is not available due to too few sequences are selected. Report will still be generated!\n\n")
                file.rename("cluster.csv", clusterName)
                Results = c(Results, clusterName)
                file.copy(Results, folderName, overwrite = TRUE)
                file.remove(Results)
                next
        }
        eps_clustering = append(eps_clustering, ClusteringRet)
        log = paste0(log, "\nMessage: Clustering in ", folderName, " is completed. Report will be generated!")
        file.rename("cluster.csv", clusterName)
        file.rename("cluster.png", paste0("Cluster_",tag,".png"))

        Results = c(Results, clusterName, paste0("Cluster_",tag,".png"))

        #Repopulate un-clustered sequences to clusters
        baseCluster = read.csv(clusterName, header = TRUE, stringsAsFactors = FALSE)
        baseCluster = baseCluster%>%select(Seq, Cluster, CorePoints)
        baseCluster$Cluster = paste0(tag,'_',baseCluster$Cluster)
        tmp = unlist(strsplit(baseCluster$Seq[1],'-'))
        if(length(tmp)==2){
                baseCluster = separate(baseCluster,'Seq',c('Mod','Seq'), sep = '-')
                baseCluster$N = sapply(baseCluster$Seq, nchar)
                maxN = max(baseCluster$N)
                baseCluster$Seq = paste0(baseCluster$Mod,'-',baseCluster$Seq, sapply(baseCluster$N, function(x,reps){paste0(rep('G', reps-x), collapse = '')}, reps = maxN))
                baseCluster = select(baseCluster,-Mod,-N)
        }else{
                baseCluster$N = sapply(baseCluster$Seq, nchar)
                maxN = max(baseCluster$N)
                baseCluster$Seq = paste0(baseCluster$Seq, sapply(baseCluster$N, function(x,reps){paste0(rep('G', reps-x), collapse = '')}, reps = maxN))
                baseCluster = select(baseCluster,-N)
        }
        newSeq = baseCluster
        names(newSeq) = c('Seq', 'OriginCluster','OriginCorePoints')
        print("repopulation")
        print(head(baseCluster))
        newTbl = repopulation(baseCluster, newSeq$Seq, ClusteringRet, uMod)
        newTbl = left_join(newTbl, newSeq, by = 'Seq')
        write.csv(newTbl, paste0('rePopulate_', tag, '_to_', tag, '.csv'), quote = FALSE, row.names = FALSE)
        Results = c(Results, paste0('rePopulate_', tag, '_to_', tag, '.csv'))

        ReportParams = list("dataFolder"="", "reportGroup"= reportGroup, "ctrSet"=SoftDEControls, "Groups"= Groups,
                            "fileList"=fileList, "seqHead"= seqHead, "extraComp" = extraComp, 'blackPos'=blackPos, 'VolcanoDIR' = paste0(folderName,'/'), "subtitle" = subtitle, "library" = library, 'tarGel' = tarGel)
        render("DEAnalysisReport.rmd", params = ReportParams)

        file.rename("DEAnalysisReport.pdf", paste0(tag,".pdf"))

        Results = c(Results, paste0(tag,".pdf"))

        file.copy(Results, folderName, overwrite = TRUE)

        file.remove(Results)
}

write.table(log, 'log.txt', quote = FALSE, row.names = FALSE)

