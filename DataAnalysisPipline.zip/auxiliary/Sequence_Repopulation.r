
# Sequence_Repopulation.r
# author: Jessica CAO
# Date: August 08, 2018
#
# This script includes functions used to do the repopulation of sesquences
# Functions
# 1. interpretSequence(sequence, descriptor) -- interpret sequences by using the specified descriptor 
# 2. getIndex(corePoints, newPoint, eps) -- find the index of the nearest corepoint less than eps, return the index and the minimum distance, if not reclustered, find the closest cluster and the min dist
# 3. repopulation(clusters, newList, eps) -- find map the sequence to cluster
#       Input: 
#               1. clusters must be an data frame containing at least 3 columns 
#               (Seq--only seq !!! no modification attached, Cluster--cluster label, CorePoints -- 1 or 0)
#               2. newList is a list of sequences need to be repopulated
#               3. eps the distance threshold for the repopulation
#       return: newTbl(Seq, repo--(1/0), NewCluster, Dist)

library(dplyr)
library(tidyr)

BLOSUM62 = list('A'=c(0.077, -0.916, 0.526, 0.004, 0.240, 0.190, 0.656, -0.047, 1.357, 0.333),
                'R'= c(1.014, 0.189, -0.860, -0.609, 1.277, 0.195, 0.661, 0.175, -0.219, -0.520),
                'N'= c(1.511, 0.215, -0.046, 1.009, 0.120, 0.834, -0.033, -0.570, -1.200, -0.139),
                'D'= c(1.551, 0.005, 0.323, 0.493, -0.991, 0.010, -1.615, 0.526, -0.150, -0.282),
                'C'= c(-1.084, -1.112, 1.562, 0.814, 1.828, -1.048, -0.742, 0.379, -0.121, -0.102),
                'Q'= c(1.094, 0.296, -0.871, -0.718, 0.500, -0.080, -0.442, 0.202, 0.384, 0.667),
                'E'= c(1.477, 0.229, -0.670, -0.355, -0.284, -0.075, -1.014, 0.363, 0.769, 0.298),
                'G'= c(0.849, 0.174, 1.726, 0.093, -0.548, 1.186, 1.213, 0.874, 0.009, 0.242),
                'H'= c(0.716, 1.548, -0.802, 1.547, 0.350, -0.785, 0.655, -0.076, -0.186, 0.990),
                'I'= c(-1.462, -1.126, -0.761, 0.382, -0.599, 0.276, -0.132, 0.198, -0.216, 0.207),
                'L'= c(-1.406, -0.856, -0.879, -0.172, 0.032, 0.344, 0.109, 0.146, -0.436, -0.021),
                'K'= c(1.135, -0.039, -0.802, -0.849, 0.819, 0.097, 0.213, 0.129, 0.176, -0.850),
                'M'= c(-0.963, -0.585, -0.972, -0.528, 0.236, 0.365, 0.062, 0.208, -0.560, 0.361),
                'F'= c(-1.619, 1.007, -0.311, 0.623, -0.549, 0.290, -0.021, 0.098, 0.433, -1.288),
                'P'= c(0.883, -0.675, 0.382, -0.869, -1.243, -2.023, 0.845, -0.352, -0.421, -0.298),
                'S'= c(0.844, -0.448, 0.423, 0.317, 0.200, 0.541, 0.009, -0.797, 0.624, -0.129),
                'T'= c(0.188, -0.733, 0.178, -0.012, 0.022, 0.378, -0.304, -1.958, 0.149, 0.063),
                'W'= c(-1.577, 2.281, 1.166, -1.610, 0.122, 0.239, -0.542, -0.398, -0.349, 0.499),
                'Y'= c(-1.142, 1.740, -0.582, 0.747, -0.119, -0.475, 0.241, -0.251, 0.713, -0.251),
                'V'= c(-1.127, -1.227, -0.633, 0.064, -0.596, 0.158, 0.014, 0.016, 0.251, 0.607))

##################################################################################
# interpretSequence(sequence, descriptor)
# This function interpret sequences by using the specified descriptor 
interpretSequence = function(sequence, descriptor = BLOSUM62){
        Seq = unlist(strsplit(sequence,'-'))
        if(length(Seq)==1){
                Seq = strsplit(sequence,'')
        }else{
                
                Seq = c(Seq[1],unlist(strsplit(Seq[2],'')))
        }
        if (exists('vSeq')){
                remove('vSeq')
        }
        for (s in Seq){
                if (!exists('vSeq')){
                        vSeq = as.numeric(unlist(descriptor[s]))
                }else{
                        vSeq = append(vSeq,as.numeric(unlist(descriptor[s])))
                }
        }
        return(vSeq)
}
###################################################################################

###################################################################################
# getIndex(corePoints, newPoint, eps)
# This function find the index of the nearest corepoint less than eps
# return the index and the minimum distance, if not reclustered, find the closest cluster and the min dist
getIndex = function(corePoints, newPoint, eps){
        distance = dist(rbind(newPoint, corePoints))[1:nrow(corePoints)]
        if(min(distance)<=eps){
                return(c(1, which(distance == min(distance))[1], min(distance)))
        }else{
                return(c(-1, which(distance == min(distance))[1], min(distance)))
        }
}
#################################################################################

#################################################################################
# repopulation(clusters, newList, eps)
# This function find map the sequence to cluster
# Input: 
#       1. clusters must be an data frame containing at least 3 columns 
#       (Seq--only seq !!! no modification attached, Cluster--cluster label, CorePoints -- 1 or 0)
#       2. newList is a list of sequences need to be repopulated
#       3. eps the distance threshold for the repopulation
# return: newTbl(Seq, repo--(1/0), NewCluster, Dist)
repopulation = function(clusters, newList, eps, uMod){
        print("recalculation")
        cTbl = clusters
        # get the modification parts
        descriptors = BLOSUM62
        if(uMod!=''){
                uMod = unlist(strsplit(uMod,','))
                Nfeature = length(descriptors['A'])
                mCNT = 0
                print('unique modifications:')
                print(uMod)
                for(umod in uMod){
                        tmp = rep(0, Nfeature)
                        tmp[(mCNT%%Nfeature)+1] = 10**(ceiling(mCNT/Nfeature))
                        descriptors[[umod]] = tmp
                        mCNT = mCNT+1
                }
        }
        # get the core points in the clusters, and interpret them
        cTbl = cTbl[cTbl$CorePoints==1, c("Seq", "Cluster")]
        corePoints = sapply(cTbl$Seq,interpretSequence, descriptor = descriptors)
        corePoints = t(corePoints)
        
        # get the new list, and interpret them
        newCluster = rep(-1, length(newList))
        newTbl = data.frame(newList, newCluster)
        names(newTbl) =c('Seq', 'NewCluster')
        newTbl$Seq = as.character(newTbl$Seq)
        newPoints = sapply(newTbl$Seq, interpretSequence, descriptor = descriptors)
        newPoints = t(newPoints)
        
        # get the index and the distance of the nearest core points 
        ret = apply(newPoints, 1, getIndex, corePoints = corePoints, eps = eps)
        newTbl$NewCluster[ret[2,]!=-1] = cTbl$Cluster[ret[2,ret[2,]!=-1]]
        newTbl$Dist = ret[3,]
        newTbl$Repo = ret[1,]
        newTbl = arrange(newTbl, desc(NewCluster))
        return(newTbl)
}
##################################################################################

#################################################################################
# clusterCenter(file)
# This function find the cluster center
# return: ccTbl(points, Label)
clusterCenter = function(file, Tag){
        cTbl = read.csv(file, header = 1, stringsAsFactors = FALSE)
        # get the core points in the clusters, and interpret them
        cTbl = cTbl[cTbl$CorePoints==1, c("Seq", "Cluster")]
        corePoints = sapply(cTbl$Seq,interpretSequence)
        corePoints = t(corePoints)
        tmp = data.frame(corePoints)
        names(tmp) = paste0('P',1:dim(tmp)[2])
        tmp$Tag = paste0(Tag,"-C",cTbl$Cluster+1)
        
        ccTbl = tmp%>%group_by(Tag)%>%summarise_all(mean)
        return(ccTbl)
}
##################################################################################
