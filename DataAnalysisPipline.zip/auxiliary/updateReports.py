# updateReports
# Author: Jessica CAO
# Date: Jan, 2018

import os
from UserInterface import UI
from DBProcess import dbconnection
import pandas as pd 
import numpy as np
import re

class updateReports():

	def __init__(self, datadir, dbcon):
		self.datadir = datadir
		self.ui = UI('\nUpdate Report Information:')
		self.dbcon = dbcon
		self.reportFolder = 'DEClusteringReport/'
		return

	# generate SQL for update reportidlist in TableFiles
	# tid = table file id, rid = report file id
	def ReportIDListGen(self, tid, rid):
		SQL = "SELECT ReportIDList FROM TableFiles WHERE ID = %s" %tid
		tmp = self.dbcon.search(SQL)
		ridlist = tmp.ReportIDList[0]
		if (ridlist == '' or ridlist == None):
			tmp = rid
		else:
			tmp = ridlist+','+str(rid)
		return "Update TableFiles Set ReportIDList = '%s' WHERE ID = %s"%(tmp, tid)

	# main process of update report list
	def update(self):
		while 1:
			# get the date of the sample
			while 1:
				self.reportTblName = self.ui.getInput('Please store the report table as .xlsx file in the folder : %s.\nPlease enter the name of the .xlsx file:'%(self.datadir))

				if len(self.reportTblName.split("."))==1:
					self.reportTblName += '.xlsx'

				if (not os.path.isfile(os.path.join(self.datadir, self.reportTblName))):
					self.ui.printMsg('[Error] File %s is found! '%os.path.join(self.datadir, self.reportTblName))
					tmp = self.ui.getInput('Do you want to continue? [y/n]')
					if tmp.lower() == 'n':
						self.ui.printMsg('Exiting update report information!')
						return 
				else:
					self.reportTbl = pd.read_excel(os.path.join(self.datadir, self.reportTblName), header = 0, na_filter = False)
					self.cols = list(self.reportTbl.columns)	
					if ('test' not in self.cols) or ('tag' not in self.cols):
						self.ui.printMsg('[Error] the report table file is invalid! Please make sure there are columns "Report" and "test" in the columne!\nExiting update report information!' )
						return 
					break
			try:
				Ccols = [s for s in self.cols if s.startswith('control')]

				if (not self.reportTbl.empty):
					for ind,row in self.reportTbl.iterrows():
						if(row['tag']==""):
							continue
						rloc = self.reportFolder + row['tag'] + '.pdf'
						# get the list of control ids
						ctrs = len([row[ccol] for ccol in Ccols if row[ccol]!=''])

						if ctrs == 0:
							self.ui.printMsg('[Error] No control files are in the table for %s in the Database. Information not updated!' % row["Report"])
							continue
						ctrlist ="'" + "','".join([row[ccol] for ccol in Ccols if row[ccol]!='']) +"'"
						SQL = "SELECT ID FROM TableFiles WHERE FileName IN (%s)" % ctrlist

						ctrIDs = self.dbcon.search(SQL)
						ctrlist = ','.join([str(id) for id in ctrIDs.ID])

						SQL = "SELECT ID FROM TableFiles WHERE FileName = '%s'" % row['test'] 
						testID = self.dbcon.search(SQL)
						if ctrIDs.shape[0]<ctrs or testID.empty:
							self.ui.printMsg('[Error] Can not find test or control files for %s in the Database. Information not updated!' % row["Report"])
							continue
						SQL = "INSERT INTO ReportTable(TestFileID, Location, ControlFileIDs) VALUES (%s, '%s', '%s')" % (testID.ID[0], rloc, ctrlist)

						self.dbcon.execute(SQL)

						# update table file list
						SQL = "SELECT ID FROM ReportTable WHERE Location = '%s'" % rloc
						reportID = self.dbcon.search(SQL)
						reportID = reportID.ID[0]

						# update test file
						SQL = self.ReportIDListGen(testID.ID[0], reportID)
						self.dbcon.execute(SQL)
						
						# update control files
						for cid in ctrIDs.ID:
							SQL = self.ReportIDListGen(cid, reportID)
							self.dbcon.execute(SQL)
						self.ui.printMsg('[Info] Report %s.pdf information updated\n'%row['tag'])
			except:
				self.ui.printMsg('[Error] Database execution error! Exiting update report information!')
				return

			self.ui.printMsg('[Info]: Done!')
			tmp = self.ui.getInput('Do you want to update information from another report table? [y/n]')
			if tmp.lower() == 'n':
				self.ui.printMsg('Exiting update report table!')
				return 
		