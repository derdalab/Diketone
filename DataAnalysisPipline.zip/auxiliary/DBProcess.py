# DBProcess.py
# Author: Jessica CAO
# Date: Oct, 2018
# this is a basic class to realise functions associated with database

import pymysql
pymysql.install_as_MySQLdb()
import MySQLdb as mysql 
import getpass
import datetime
import re
import os
import pandas as pd 
import sys
from glob import glob

# class db interface
class dbconnection:
  def __init__(self, dbAddr, dbUser, dbPWD, dbSchema):
    self.db = mysql.connect(dbAddr, dbUser, dbPWD, dbSchema)
    self.cursor = self.db.cursor()
    return

  def disconnect(self):
    self.db.close()
    return 

  def execute(self, sql):

    self.cursor.execute(sql)
    self.db.commit()
    return 

  def search(self,sql):
    return pd.read_sql(sql, self.db)