

# default is to select the top 1000 sequence to search
# however, if there are less than 1000 sequences satisfy p<0.1 and R>2, cluster all the sequences
# if there are less than 3 sequence, no clustering will be performed
# default settings for clustering:
# Sample size is set to 3
# Best Clusters is defined by the eps value gives the most clusters

from glob import glob
import numpy as np
import collections
from scipy import stats
from scipy import spatial
from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.preprocessing import StandardScaler
import pandas as pd
import sys
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button, RadioButtons
import matplotlib.pyplot as plt 
from matplotlib import transforms, cm
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.neighbors import NearestNeighbors
import math

BLOSUM62 = {'A': [0.077, -0.916, 0.526, 0.004, 0.240, 0.190, 0.656, -0.047, 1.357, 0.333],
            'R': [1.014, 0.189, -0.860, -0.609, 1.277, 0.195, 0.661, 0.175, -0.219, -0.520],
            'N': [1.511, 0.215, -0.046, 1.009, 0.120, 0.834, -0.033, -0.570, -1.200, -0.139],
            'D': [1.551, 0.005, 0.323, 0.493, -0.991, 0.010, -1.615, 0.526, -0.150, -0.282],
            'C': [-1.084, -1.112, 1.562, 0.814, 1.828, -1.048, -0.742, 0.379, -0.121, -0.102],
            'Q': [1.094, 0.296, -0.871, -0.718, 0.500, -0.080, -0.442, 0.202, 0.384, 0.667],
            'E': [1.477, 0.229, -0.670, -0.355, -0.284, -0.075, -1.014, 0.363, 0.769, 0.298],
            'G': [0.849, 0.174, 1.726, 0.093, -0.548, 1.186, 1.213, 0.874, 0.009, 0.242],
            'H': [0.716, 1.548, -0.802, 1.547, 0.350, -0.785, 0.655, -0.076, -0.186, 0.990],
            'I': [-1.462, -1.126, -0.761, 0.382, -0.599, 0.276, -0.132, 0.198, -0.216, 0.207],
            'L': [-1.406, -0.856, -0.879, -0.172, 0.032, 0.344, 0.109, 0.146, -0.436, -0.021],
            'K': [1.135, -0.039, -0.802, -0.849, 0.819, 0.097, 0.213, 0.129, 0.176, -0.850],
            'M': [-0.963, -0.585, -0.972, -0.528, 0.236, 0.365, 0.062, 0.208, -0.560, 0.361],
            'F': [-1.619, 1.007, -0.311, 0.623, -0.549, 0.290, -0.021, 0.098, 0.433, -1.288],
            'P': [0.883, -0.675, 0.382, -0.869, -1.243, -2.023, 0.845, -0.352, -0.421, -0.298],
            'S': [0.844, -0.448, 0.423, 0.317, 0.200, 0.541, 0.009, -0.797, 0.624, -0.129],
            'T': [0.188, -0.733, 0.178, -0.012, 0.022, 0.378, -0.304, -1.958, 0.149, 0.063],
            'W': [-1.577, 2.281, 1.166, -1.610, 0.122, 0.239, -0.542, -0.398, -0.349, 0.499],
            'Y': [-1.142, 1.740, -0.582, 0.747, -0.119, -0.475, 0.241, -0.251, 0.713, -0.251],
            'V': [-1.127, -1.227, -0.633, 0.064, -0.596, 0.158, 0.014, 0.016, 0.251, 0.607]}

AAColor = {"G": "green", "S": "green", "T": "green", "Y": "green", "C": "green", "Q": "green", "N": "green",
			"A": "orange", "V": "orange", "L": "orange", "I": "orange", "P": "orange", "W": "orange", "F": "orange", "M": "orange",
			"D": "red", "E": "red", "K": "blue", "R": "blue", "H": "blue"}

def DispViolin(AAMatrix, position=0, ax = None):
	nsamples = min(3, AAMatrix.shape[0])
	if AAMatrix.shape[0]>1:
		nbrs = NearestNeighbors(n_neighbors = nsamples).fit(AAMatrix)
		distances, indices = nbrs.kneighbors(AAMatrix)
		minpdist = distances[:,1:nsamples].min(axis=1)
	else:
		minpdist = 0
	ax.violinplot(minpdist, [position], showmedians = True)
	ax.set_ylabel("Min Pairwise Distance")
	ax.set_xlabel("")
	ax.grid(True)

#  function to print list of sequences horizontally
#  x, y, lower left points, color = True use AAColor, otherwise, default is black 
def DispSeq(x, height, strList, color=False, ax = None, **kw):
	maxLen = np.array(list(map(len,strList))).max()
	if ax is None:
		ax = plt.gca()
	t = ax.transData
	canvas = ax.figure.canvas

	text = ax.text(x, 0, strList[0][0], color = 'None', transform = t, family = 'monospace', **kw)
	text.draw(canvas.get_renderer())
	ex = text.get_window_extent()
	textHeight = ex.height
	textWidth = ex.width
	t = transforms.offset_copy(text._transform, x = -int(maxLen/2)*textWidth, y = textHeight, units='dots')
	barHeight = t.transform((0,height))[1]-t.transform((0,0))[1]
	maxStr = int(barHeight/textHeight)-3

	
	if not color:
		color = 'black'
		if len(strList)>maxStr:
			t = transforms.offset_copy(t, x = 2*textWidth, units = 'dots')
			tmp = "%s +" %(len(strList)-maxStr)
			text = ax.text(x, 0, tmp, color = color, transform = t, family = 'monospace', **kw)
			text.draw(canvas.get_renderer())
			t = transforms.offset_copy(text._transform, x = -2*textWidth,y = textHeight, units = 'dots')

		for s in strList[0: min(len(strList), maxStr)]:
			text = ax.text(x, 0, s, color = color, transform = t, family = 'monospace', **kw)
			text.draw(canvas.get_renderer())
			ex = text.get_window_extent()
			t = transforms.offset_copy(text._transform, y = textHeight, units = 'dots')
	else:
		color = 'black'
		if len(strList)>maxStr:
			t = transforms.offset_copy(t, x = 2*textWidth, units = 'dots')
			tmp = "%s +" %(len(strList)-maxStr)
			text = ax.text(x, 0, tmp, color = color, transform = t, family = 'monospace', **kw)
			text.draw(canvas.get_renderer())
			t = transforms.offset_copy(text._transform,x = -2*textWidth,y = textHeight, units = 'dots')
	
		for s in strList[0:min(len(strList),maxStr)]:
			startPoint = str.find(s,'-')
			tmpT = t
			for ss in s[0:(startPoint+1)]:
				if ss!=" ":
					text = ax.text(x, 0, ss, color = 'black', transform = tmpT, family = 'monospace', **kw)
					text.draw(canvas.get_renderer())
					ex = text.get_window_extent()
					t0 = text._transform
					tmpT = transforms.offset_copy(text._transform, x = ex.width, units = 'dots')
			for ss in s[(startPoint+1):len(s)]:
				if ss!=" ":
					text = ax.text(x, 0, ss, color = AAColor[ss], transform = tmpT, family = 'monospace', **kw)
					text.draw(canvas.get_renderer())
					ex = text.get_window_extent()
					t0 = text._transform
					tmpT = transforms.offset_copy(text._transform, x = ex.width, units = 'dots')
			t = transforms.offset_copy(t, y = ex.height, units = 'dots')


# expand string x with n of y
def expand(x, y, n):
	tmp = x + y*n
	return tmp

def DBSCANClustering(fileName, step = 0.01, pThresh = 0.05, RThresh = 2, RThreshDes = None, SeqNum = 0, descriptors = BLOSUM62, desc = 'BLOSUM62', retDir='', selectHits = "true"):
	descriptors = descriptors
	uMod = ''
	#  read the file and get the sequences
	orTbl = pd.read_csv(fileName, delim_whitespace=True, header = 0)
	if selectHits == 'true':
		orTbl = orTbl.loc[orTbl.SPmax<=pThresh,]
		orTbl = orTbl.loc[orTbl.SRmin>= math.log2(RThresh),]
		if RThreshDes is not None:
			if "logFC_B" in orTbl.columns:
				#keep = [not(x & y) for x,y in zip(orTbl.logFC_B<=math.log2(RThreshDes), orTbl.PValue_B<=pThresh)]
				keep = orTbl.logFC_B>=math.log2(RThreshDes)
				orTbl = orTbl.loc[keep,]
				del keep
			if "logFC_UC" in orTbl.columns:
				#keep = [not(x & y) for x,y in zip(orTbl.logFC_B<=math.log2(RThreshDes), orTbl.PValue_B<=pThresh)]
				keep = orTbl.logFC_B<=math.log2(RThreshDes)
				orTbl = orTbl.loc[keep,]
				del keep

		if "logFC_UT" in orTbl.columns:
			#keep = [not(x & y) for x,y in zip(orTbl.logFC_U>=math.log2(RThresh), orTbl.PValue_U<=pThresh)]
			keep = orTbl.logFC_U<=math.log2(RThresh)
			orTbl = orTbl.loc[keep,]
			del keep
		


		# more than 1500 sequence to cluster return -3
		if (len(orTbl.sequence) >1500):
			return -3, uMod

		# no sequence to cluster return -2
		if (len(orTbl.sequence) == 0):
			return -2, uMod
	tmp1 = orTbl.SPmax.apply(lambda x: math.pow(math.log10(1/max(x,1e-30)),2))
	tmp2 = orTbl.SRmin.apply(lambda x: math.pow(x,2))
	tmp = tmp1+tmp2
	tmp = tmp.apply(lambda x: math.sqrt(x))
	orTbl['pRValue'] = tmp
	orTbl.sort_values(by = 'pRValue', ascending=False, inplace = True)
    # less than 3 sequence to cluster return -1
	if (len(orTbl.sequence) < 3):
		orTbl["Cluster"] = [0 for i in range(0, len(orTbl.sequence))]
		pd.DataFrame.to_csv(orTbl,'cluster.csv', index=False )
		return -1, uMod

	#  set the default number of sequences to be clustered
	if SeqNum >0:	
		Nseq_0 = min(1000,len(orTbl.pRValue))
	else:
		Nseq_0 = len(orTbl.pRValue)
	Nseq_old = Nseq_0
	thresh_pr = orTbl.pRValue.iloc[Nseq_0-1]
	SeqTbl = orTbl.loc[orTbl.pRValue >= thresh_pr,]

	SeqTbl = SeqTbl.rename(columns={'sequence':'Seq'})
	SeqTbl.reset_index(drop = True, inplace = True)
	SeqList = SeqTbl.Seq
	print('\n#File %s contains %s unique sequences' % (fileName, len(SeqList)))

	#calculate average lenghth of the peptides
	lenMin = np.array(list(map(lambda x: len(x[(str.find(x,'-')+1):len(x)]),SeqList))).min()
	lenMax = np.array(list(map(lambda x: len(x[(str.find(x,'-')+1):len(x)]),SeqList))).max()
	print(lenMin)
	print("\n")
	print(lenMax)
	
	if not lenMin == lenMax:
		print('\n#Since the lengths of the sequences vary in the file, all sequences will be expanded to the MINIMUM length %d with "G" in the end.' % lenMax)
		SeqListS = list(map(lambda x: expand(x, 'G', (lenMax-len(x[(str.find(x,'-')+1):len(x)]))), SeqList) )
		SeqTbl['SeqS'] = SeqListS
	else: 
		SeqListS = SeqList

	SeqListS = np.array(SeqListS)
	#unique seq and the index in SeqListS for i in index[j], SeqListS[j]=uSeqListS[i]
	uSeqListS, index = np.unique(SeqListS,return_inverse=True) 																										

	print('\n#Using amino acid description system BLOSUM62 (10 terms) for clustering...')

	# auto assign modification features
	if len(str.split(uSeqListS[0],'-'))==2:
		Nfeature = len(descriptors['A'])
		uMod = [str.split(seq,'-')[0] for seq in uSeqListS]
		uMod = np.unique(np.array(uMod))
		mCNT = 0
		for umod in uMod:
			tmp = [0] * Nfeature
			tmp[mCNT%Nfeature] = 10**(math.floor(mCNT/Nfeature)+1)
			descriptors[umod] = tmp
			mCNT += 1
		uMod = ','.join(uMod)

	AADescMatrix = []
	for seq in uSeqListS:
		tmp = []
		if len(str.split(seq,'-'))==2:
			mod = str.split(seq,'-')[0]
			tmp.append(descriptors[mod])
		startPoint = str.find(seq,'-')
		for aa in seq[(startPoint+1): len(seq)]:
			if aa in descriptors.keys():
				tmp.append(descriptors[aa.upper()])
			else:
				# if the aa is not found, use 'G' for instance aa='*'
				tmp.append(descriptors['G']) 
		tmp = np.array(tmp).flatten()
		AADescMatrix.append(tmp)
		
	AADescMatrix=np.array(AADescMatrix)
	Size=len(uSeqListS) #find total number of unique sequences

	X = AADescMatrix
	print(X[0:3,0:20])
	XDistMatrix = spatial.distance.pdist(X)
	Rmin = XDistMatrix.min()
	Rmax = XDistMatrix.max()

	# set initial eps, mspl
	eps = max(Rmin,0.01)
	mspl = 3
	eps_opt = eps
	score = 0 # score is set to the total number of clusters
	score_opt = score
	step = 0.01 # iteration steps
	nNoise = len(SeqListS)
	print('\nTotal %d Runs' % (math.floor((Rmax-Rmin)/step)))

	# for loop find the best cluster
	while(eps<=Rmax and nNoise != 0):
		# print(eps)
		# print(nNoise)
		cluster = DBSCAN(eps = eps, min_samples = mspl, metric = 'euclidean').fit(X)
		#  get cluster labels
		labels = cluster.labels_
		# count cluter and noise numbers
		n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
		score = n_clusters
		noiseIndex = list(map(lambda x: x==-1, list(labels)))
		nNoise = sum(noiseIndex)

		if score > score_opt:
			print('\n Score Updated: %d' % score)
			n_clusters_opt = n_clusters
			score_opt = score
			eps_opt = eps
			labels_opt = labels
			
			SeqTbl['Cluster'] = pd.Series(list(map(lambda x: labels[x], index)))
			CoreLabels = np.zeros((labels.shape[0],1))
			CoreLabels[cluster.core_sample_indices_] = int(1)
			SeqTbl['CorePoints'] = pd.Series(list(map(lambda x: CoreLabels[x,0], index)))

		eps = eps + step

	# plot the best cluster
	# initial plotting
	fig = plt.figure(figsize = [40,20])
	# fig.subplots_adjust(left=0.1,bottom=0.35)
	fig.subplots_adjust(left=0.1)
	# plt.figure(1)
	axe = fig.add_subplot(211)
	nbins = n_clusters_opt + (1 if -1 in labels_opt else 0)
	counts, bins, patches = axe.hist(SeqTbl.Cluster, nbins,rwidth=0.8,facecolor='None', edgecolor='None')
	axe.set_xlabel('')
	fig.suptitle('Clusters of %d sequences using %s \n with MaxDist = %.2f, MinSize = %d' % (len(SeqTbl.Seq),desc,eps_opt,mspl))
	#  set xticks and xticklabels
	if -1 in labels_opt:
		xtick = list(range(-1,n_clusters_opt))
	else:
		xtick = list(range(n_clusters_opt))
	xlabels = ['%s' % str(i) for i in xtick]
	xticks = [x+(bins.max()-bins.min())/(len(bins)-1)/2 for x in bins]
	axe.set_yticklabels([])
	height = axe.get_ylim()[1]
	for rect,n, binIndex in zip(patches, counts,range(nbins)):
	    seqList = list(SeqTbl.Seq[SeqTbl.Cluster ==(binIndex - (1 if -1 in labels_opt else 0))])
	    seqList = ["%s" % (s+' '*(lenMax-len(s)))  for s in seqList]
	    seqLogoSize = 12 if nbins<=14 else 8
	    DispSeq(rect.get_x() + rect.get_width()/2, height, seqList, color=True, ax = axe, ha = 'center', fontsize = seqLogoSize)
	
	axeViolin = fig.add_subplot(223)
	for l,t in zip(xtick, xticks):
		# tmpTbl = X[(SeqTbl['Cluster']==l) & (SeqTbl['CorePoints']==1),:]
		tmpTbl = X[labels_opt==l,:]
		DispViolin(tmpTbl, t, axeViolin)

	if xlabels[0]=='-1':
		xlabels[0] = 'Noise'
	axe.set_xticks(xticks)
	axe.set_xticklabels(xlabels)
	axeViolin.set_xticks(xticks)
	axeViolin.set_xticklabels(xlabels)

	# tmpc = orTbl.pRValue.apply(lambda x: 'red' if (x>=thresh_pr) else 'lightgrey')
	orTbl['color'] = orTbl.pRValue.apply(lambda x: 'red' if (x>=thresh_pr) else 'lightgrey')
	axeVolcano = fig.add_subplot(224)
	orTbl['SPmaxlog'] = orTbl.SPmax.apply(lambda x: math.log10(1/max(x,1e-30)))
	axeVolcano.scatter(x = orTbl.SRmin, y = orTbl.SPmaxlog, c = orTbl.color, alpha = 0.5, s = 3)
	axeVolcano.set_xlabel("log2(FC)")
	axeVolcano.set_ylabel("-log10(p)")
	fig.savefig(retDir+'cluster.png', bbox_inches='tight', orientation = 'landscape', papertype = 'letter')

	tbl = SeqTbl.sort_values(by=['Cluster'],ascending = 0)
	pd.DataFrame.to_csv(tbl,retDir+'cluster.csv', index=False )
	return eps_opt, uMod


# DBSCANClustering('/media/Data/tmp/Ali201907/request1/DE_Report1.txt', step = 0.01, retDir = '/media/Data/tmp/Ali201907/request1/',pThresh = 0.05, RThresh = 4.5, RThreshDes = 0.7)
