# UserInterface.py
# Author: Jessica CAO
# Date:  Sep. 7, 2018
# This script contains a class of user interface

import sys

class UI:

	# init function
	def __init__(self, msg=None):
		self.input = ''
		if msg!=None:
			self.printMsg(msg)

	# define the function of getting str input from user
	def getInput(self,msg):
		# get the version of python
		vPython = sys.version_info[0]
		if vPython==3:
			self.input = input(msg)
		else:
			self.input = raw_input(msg)

		return self.input

	def printMsg(self, msg=""):
		print(msg)